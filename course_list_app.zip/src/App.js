import React from 'react'
import './App.css'
import Header from './Components/Header/Header'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Courses from './Components/Courses/Courses'
import Error from './Components/Error/Error'
import Enquiry from './Components/Enquiry/Enquiry'
import EnquiryList from './Components/Enquiry/EnquiryList'
const App = () => {
  return (
    <BrowserRouter>
      <div className='app-container'>
        <Header />
        <Routes>
          <Route path='/' element={<Courses />} />
          <Route path='/enquiry'>
            <Route index element={<EnquiryList/>}/>
            <Route path=':id' element={<Enquiry/>}/>
          </Route>
          <Route path='/*' element={<Error />} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

export default App