import React from 'react'
import './Header.css'
import { Link, NavLink } from 'react-router-dom'
const Header = () => {
  const isActive = ({ isActive }) => {
    return isActive ? 'active sub-text' : 'link sub-text'
  }
  return (
    <div className='header'>
      <span className='title'>Courses</span>
      <div className='nav-link-wrapper'>
        <NavLink to="/" className={isActive}>Home</NavLink>
        <NavLink to="/enquiry" end className={isActive}>User Enquiries</NavLink>
      </div>
    </div>
  )
}

export default Header